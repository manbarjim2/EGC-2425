from core.blueprints.base_blueprint import BaseBlueprint

profile_bp = BaseBlueprint('profile', __name__, template_folder='templates')
